
#include "insertPDF.h"


   InsertPDF::_IOleObject::_IConnectionPointContainer::_IConnectionPointContainer(_IOleObject *pp) : pParent(pp) { 
   return;
   }

   InsertPDF::_IOleObject::_IConnectionPointContainer::~_IConnectionPointContainer() {
   return;
   }

   HRESULT InsertPDF::_IOleObject::_IConnectionPointContainer::QueryInterface(REFIID riid,void **ppv) {
   return pParent -> QueryInterface(riid,ppv);
   }

   STDMETHODIMP_(ULONG) InsertPDF::_IOleObject::_IConnectionPointContainer::AddRef() {
   return pParent -> AddRef();
   }

   STDMETHODIMP_(ULONG) InsertPDF::_IOleObject::_IConnectionPointContainer::Release() {
   return pParent -> Release();
   }


   STDMETHODIMP InsertPDF::_IOleObject::_IConnectionPointContainer::EnumConnectionPoints(IEnumConnectionPoints **ppEnum) {

   _IConnectionPoint *connectionPoints[2];

   *ppEnum = NULL;
 
   if ( pParent -> enumConnectionPoints ) 
      delete pParent -> enumConnectionPoints;
 
   connectionPoints[1] = &pParent -> connectionPoint_PropertyNotifySink;
   connectionPoints[0] = &pParent -> connectionPoint_CursiVisionEvents;

   pParent -> enumConnectionPoints = new _IEnumConnectionPoints(pParent,connectionPoints,2);
 
   return pParent -> enumConnectionPoints -> QueryInterface(IID_IEnumConnectionPoints,(void **)ppEnum);
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IConnectionPointContainer::FindConnectionPoint(REFIID riid,IConnectionPoint **ppCP) {

   *ppCP = NULL;

   if ( IID_IPropertyNotifySink == riid ) 
      return pParent -> connectionPoint_PropertyNotifySink.QueryInterface(IID_IConnectionPoint,(void **)ppCP);

   if ( IID_ICursiVisionEvents == riid ) 
      return pParent -> connectionPoint_CursiVisionEvents.QueryInterface(IID_IConnectionPoint,(void **)ppCP);

   return CONNECT_E_NOCONNECTION;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_PropertyChanged() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_PropertyNotifySink.EnumConnections(&pIEnum);
   if ( ! pIEnum ) 
      return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      IPropertyNotifySink *pClient = reinterpret_cast<IPropertyNotifySink *>(connectData.pUnk);
      pClient -> OnChanged(DISPID_UNKNOWN);
   }
   pIEnum -> Release();
   return;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_DocumentStaged() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> DocumentStaged();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_DocumentOpened() {
   IEnumConnections* pIEnum = NULL;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> DocumentOpened();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_DocumentClosed() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> DocumentClosed();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_DocumentSigned() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> DocumentSigned();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }


   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_DocumentSaved(BSTR fileName) {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> DocumentSaved(fileName);
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_AwaitingSignature() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> AwaitingSignature();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_NoPadException() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> NoPadException();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_ExitRequested() {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> ExitRequested();
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_PenDown(long x,long y) {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> PenDown(x,y);
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_PenUp(long x,long y) {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> PenUp(x,y);
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

   void InsertPDF::_IOleObject::_IConnectionPointContainer::fire_PenPoint(long x,long y) {
   IEnumConnections* pIEnum;
   CONNECTDATA connectData;
   pParent -> connectionPoint_CursiVisionEvents.EnumConnections(&pIEnum);
   if ( ! pIEnum ) return;
   while ( 1 ) {
      if ( pIEnum -> Next(1, &connectData, NULL) ) break;
      ICursiVisionEvents *pClient = reinterpret_cast<ICursiVisionEvents *>(connectData.pUnk);
      pClient -> PenPoint(x,y);
   }
   static_cast<IUnknown*>(pIEnum) -> Release();
   return;
   }

