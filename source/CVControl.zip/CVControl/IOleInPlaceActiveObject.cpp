
#include "InsertPDF.h"

   long __stdcall InsertPDF::_IOleObject::_IOleInPlaceActiveObject::QueryInterface(REFIID riid,void **ppv) {
 
   if ( IID_IOleInPlaceActiveObject == riid )
      *ppv = static_cast<IOleInPlaceActiveObject *>(this); 
   else
      return pParent -> QueryInterface(riid,ppv);

   AddRef();
  
   return S_OK; 
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IOleInPlaceActiveObject::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IOleInPlaceActiveObject::Release() {
   return pParent -> Release();
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::GetWindow(HWND *pHwnd) {
   *pHwnd = hwndMainFrame;
   return S_OK;
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::ContextSensitiveHelp(BOOL) {
   return E_NOTIMPL;
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::TranslateAccelerator(MSG*) { 
   return S_OK;   
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::OnFrameWindowActivate(BOOL) {
   return S_OK;   
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::OnDocWindowActivate(BOOL) { 
   return S_OK;   
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::ResizeBorder(LPCRECT,IOleInPlaceUIWindow *,BOOL) {   
   return S_OK;   
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IOleInPlaceActiveObject::EnableModeless(BOOL) {   
   return S_OK;   
   }