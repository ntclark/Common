
#include <windows.h>
#include <shlwapi.h>

#include <olectl.h>
#include <comcat.h>
#include <stdio.h>

#define DEFINE_DATA

#include "InsertPDF.h"

#include "CursiVision_i.h"
#include "PdfEnabler_i.c"
#include "Properties_i.c"
#include "SignaturePad_i.c"
#include "PrintingSupport_i.c"
#include "CursiVision_i.c"

int GetLocation(HWND hwnd,long key,char *szFolderLocation);

   BYTE *pRestoreControlSettings = NULL;


   class Factory : public IClassFactory {
   public:

      Factory(CLSID clsid) : theCLSID(clsid), refCount(0) {};
      ~Factory() {};
  
      STDMETHOD (QueryInterface)(REFIID riid,void **ppv);
      STDMETHOD_ (ULONG, AddRef)();
      STDMETHOD_ (ULONG, Release)();
      STDMETHOD (CreateInstance)(IUnknown *punkOuter, REFIID riid, void **ppv);
      STDMETHOD (LockServer)(BOOL fLock);
  
   private:

      CLSID theCLSID;
      int refCount;

   };
  
  
   static Factory *pObjectFactory[8] = {NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL};

   extern "C" BOOL WINAPI DllMain(HINSTANCE hI, DWORD dwReason, LPVOID) {

   switch ( dwReason ) {

   case DLL_PROCESS_ATTACH: {

      CoInitialize(NULL);

      hModule = hI;

      GetModuleFileName(hModule,szModuleName,1024);

      memset(wstrModuleName,0,256 * sizeof(OLECHAR));

      MultiByteToWideChar(CP_ACP, 0, szModuleName, -1, wstrModuleName, 1024);  

      strcpy(szProgramDirectory,szModuleName);

      char *p = strrchr(szProgramDirectory,'\\');
      if ( ! p )
         p = strrchr(szProgramDirectory,'/');
      if ( p )
         *p = '\0';

      }

      break;
  
   case DLL_PROCESS_DETACH:

      if ( pObjectFactory[0] )
         delete pObjectFactory[0];
      if ( pObjectFactory[1] )
         delete pObjectFactory[1];
      if ( pObjectFactory[2] )
         delete pObjectFactory[2];
      if ( pObjectFactory[3] )
         delete pObjectFactory[3];
      if ( pObjectFactory[4] )
         delete pObjectFactory[4];
      if ( pObjectFactory[5] )
         delete pObjectFactory[5];
      if ( pObjectFactory[6] )
         delete pObjectFactory[6];
      if ( pObjectFactory[7] )
         delete pObjectFactory[7];

      if ( savedSignatureGraphicFile[0] )
         DeleteFile(savedSignatureGraphicFile);

      if ( pRestoreControlSettings )
         delete [] pRestoreControlSettings;

      break;
  
   }
  
   return TRUE;
   }
  

   STDAPI DllCanUnloadNow(void) {
   return S_OK;
   }
  
  
   STDAPI DllGetClassObject(REFCLSID rclsid,REFIID riid,LPVOID* ppObject) {

   *ppObject = NULL;

   if ( ! pObjectFactory[0] ) 
      pObjectFactory[0] = new Factory(CLSID_CursiVision);

   if ( CLSID_CursiVision == rclsid )
      return pObjectFactory[0] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[1] ) 
      pObjectFactory[1] = new Factory(CLSID_CursiVisionPropertyPage);

   if ( CLSID_CursiVisionPropertyPage == rclsid )
      return pObjectFactory[1] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[2] ) 
      pObjectFactory[2] = new Factory(CLSID_CursiVisionBackEndPropertyPage);

   if ( CLSID_CursiVisionBackEndPropertyPage == rclsid )
      return pObjectFactory[2] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[3] ) 
      pObjectFactory[3] = new Factory(CLSID_CursiVisionControlPropertyPage);

   if ( CLSID_CursiVisionControlPropertyPage == rclsid )
      return pObjectFactory[3] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[4] ) 
      pObjectFactory[4] = new Factory(CLSID_CursiVisionTemplatePropertyPage);

   if ( CLSID_CursiVisionTemplatePropertyPage == rclsid )
      return pObjectFactory[4] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[5] ) 
      pObjectFactory[5] = new Factory(CLSID_CursiVisionRecognitionPropertyPage);

   if ( CLSID_CursiVisionRecognitionPropertyPage == rclsid )
      return pObjectFactory[5] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[6] ) 
      pObjectFactory[6] = new Factory(CLSID_CursiVisionSigningLocationsPropertyPage);

   if ( CLSID_CursiVisionSigningLocationsPropertyPage == rclsid )
      return pObjectFactory[6] -> QueryInterface(riid,ppObject);

   if ( ! pObjectFactory[7] ) 
      pObjectFactory[7] = new Factory(CLSID_CursiVisionFieldsPropertyPage);

   if ( CLSID_CursiVisionFieldsPropertyPage == rclsid )
      return pObjectFactory[7] -> QueryInterface(riid,ppObject);

   return CLASS_E_CLASSNOTAVAILABLE;
   }

  
   long __stdcall Factory::QueryInterface(REFIID iid, void **ppv) { 
   *ppv = NULL; 
   if ( iid == IID_IUnknown || iid == IID_IClassFactory ) 
      *ppv = this; 
   else 
      return E_NOINTERFACE; 
   AddRef(); 
   return S_OK; 
   } 
  
  
   unsigned long __stdcall Factory::AddRef() { 
   return ++refCount; 
   } 
  
  
   unsigned long __stdcall Factory::Release() { 
   return --refCount;
   } 
  
  
   HRESULT STDMETHODCALLTYPE Factory::CreateInstance(IUnknown *punkOuter, REFIID riid, void **ppv) { 

   *ppv = NULL; 

   if ( NULL == pInsertPDF ) {

      InsertPDF *pef = new InsertPDF(punkOuter);

      pef -> essentialInitialization();

      pInsertPDF -> ppIOleObject[0] = new InsertPDF::_IOleObject(pInsertPDF);

      pInsertPDF -> oleObjectCount = 1;

//      IOleObject *pIOleObject = NULL;
//      pef -> QueryInterface(IID_IOleObject,reinterpret_cast<void **>(&pIOleObject));

   }

   if ( CLSID_CursiVision == theCLSID ) 
      return pInsertPDF -> ppIOleObject[0] -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(0) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(1) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionControlPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(2) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(3) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(4) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(5) -> QueryInterface(riid,ppv);

   if ( CLSID_CursiVisionFieldsPropertyPage == theCLSID )
      return pInsertPDF -> ppIOleObject[0] -> PropertyPage(6) -> QueryInterface(riid,ppv);

   return S_OK;
   } 
  
  
   long __stdcall Factory::LockServer(int fLock) { 
   return S_OK; 
   }
  

   char *OBJECT_NAME[] = {"InnoVisioNate.CursiVisionControl","InnoVisioNate.CursiVisionPropertyPage",
                                       "InnoVisioNate.CursiVisionControlBackEndPropertyPage",
                                       "InnoVisioNate.CursiVisionControlPropertyPage",
                                       "InnoVisioNate.CursiVisionTemplatePropertyPage",
                                       "InnoVisioNate.CursiVisionRecognitionPropertyPage",
                                       "InnoVisioNate.CursiVisionSigningLocationsPropertyPage",
                                       "InnoVisioNate.CursiVisionFieldsPropertyPage",NULL};
   char *OBJECT_NAME_V[] = {"InnoVisioNate.CursiVisionControl.1","InnoVisioNate.CursiVisionPropertyPage.1",
                                       "InnoVisioNate.CursiVisionControlBackEndPropertyPage.1",
                                       "InnoVisioNate.CursiVisionControlPropertyPage.1",
                                       "InnoVisioNate.CursiVisionTemplatePropertyPage.1",
                                       "InnoVisioNate.CursiVisionRecognitionPropertyPage.1",
                                       "InnoVisioNate.CursiVisionSigningLocationsPropertyPage.1",
                                       "InnoVisioNate.CursiVisionFieldsPropertyPage.1"};
   GUID OBJECT_CLSID[] = {CLSID_CursiVision,CLSID_CursiVisionPropertyPage,
                                       CLSID_CursiVisionBackEndPropertyPage,
                                       CLSID_CursiVisionControlPropertyPage,
                                       CLSID_CursiVisionTemplatePropertyPage,
                                       CLSID_CursiVisionRecognitionPropertyPage,
                                       CLSID_CursiVisionSigningLocationsPropertyPage,
                                       CLSID_CursiVisionFieldsPropertyPage};
   char *OBJECT_DESCRIPTION[] = {"CursiVision Control","CursiVision main property page",
                                       "CursiVision back ends property page",
                                       "CursiVision as a Control property page",
                                       "CursiVision Document Template property page",
                                       "CursiVision Document Recognition property page",
                                       "CursiVision Signing Location(s) property page",
                                       "CursiVision Data FIelds property page"};

   STDAPI DllRegisterServer() {

   char *OBJECT_VERSION;

   OBJECT_VERSION = "1.0";

   HRESULT rc = S_OK;
   ITypeLib *ptLib;

   OLECHAR wstrPrintingSupportLibrary[MAX_PATH];
   swprintf(wstrPrintingSupportLibrary,L"%s\\2",wstrModuleName);

   if ( S_OK != LoadTypeLib(wstrPrintingSupportLibrary,&ptLib) )
      rc = ResultFromScode(SELFREG_E_TYPELIB);
   else
      if ( S_OK != RegisterTypeLib(ptLib,wstrPrintingSupportLibrary,NULL) )
         rc = ResultFromScode(SELFREG_E_TYPELIB);

   if ( S_OK != LoadTypeLib(wstrModuleName,&ptLib) )
      rc = ResultFromScode(SELFREG_E_TYPELIB);
   else
      if ( S_OK != RegisterTypeLib(ptLib,wstrModuleName,NULL) )
         rc = ResultFromScode(SELFREG_E_TYPELIB);

   HKEY keyHandle,clsidHandle;
   DWORD disposition;
   LPOLESTR oleString;
  
   for ( long objectIndex = 0; 1; objectIndex++ ) {

      if ( ! OBJECT_NAME[objectIndex] )
         break;

      char szTemp[256],szCLSID[256];

      StringFromCLSID(OBJECT_CLSID[objectIndex],&oleString);
      WideCharToMultiByte(CP_ACP,0,oleString,-1,szCLSID,256,0,0);
  
      RegOpenKeyEx(HKEY_CLASSES_ROOT,"CLSID",0,KEY_CREATE_SUB_KEY,&keyHandle);
    
      RegCreateKeyEx(keyHandle,szCLSID,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&clsidHandle,&disposition);
      sprintf(szTemp,OBJECT_DESCRIPTION[objectIndex]);
      RegSetValueEx(clsidHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
    
      if ( 0 == objectIndex ) {
         RegCreateKeyEx(clsidHandle,"Control",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
         sprintf(szTemp,"");
         RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
      }

      RegCreateKeyEx(clsidHandle,"ProgID",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      sprintf(szTemp,OBJECT_NAME_V[objectIndex]);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
    
      RegCreateKeyEx(clsidHandle,"InprocServer",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szModuleName,strlen(szModuleName));
    
      RegCreateKeyEx(clsidHandle,"InprocServer32",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szModuleName,strlen(szModuleName));
      RegSetValueEx(keyHandle,"ThreadingModel",0,REG_SZ,(BYTE *)"Apartment",9);
    
      RegCreateKeyEx(clsidHandle,"LocalServer",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szModuleName,strlen(szModuleName));
      
      if ( 0 == objectIndex ) {
         RegCreateKeyEx(clsidHandle,"Insertable",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);

         RegCreateKeyEx(clsidHandle,"Programmable",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);

         RegCreateKeyEx(clsidHandle,"TypeLib",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
       
         StringFromCLSID(LIBID_CursiVision,&oleString);
         WideCharToMultiByte(CP_ACP,0,oleString,-1,szTemp,256,0,0);
         RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
      }
           
      RegCreateKeyEx(clsidHandle,"ToolboxBitmap32",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
    
      RegCreateKeyEx(clsidHandle,"Version",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      sprintf(szTemp,OBJECT_VERSION);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
    
      RegCreateKeyEx(clsidHandle,"MiscStatus",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      sprintf(szTemp,"0");
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));

      RegCreateKeyEx(keyHandle,"1",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      sprintf(szTemp,"%ld",
                 OLEMISC_ACTIVATEWHENVISIBLE | 
                 OLEMISC_RECOMPOSEONRESIZE | 
                 OLEMISC_INSIDEOUT |
                 OLEMISC_SETCLIENTSITEFIRST );

      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
#if 0    
      RegCreateKeyEx(clsidHandle,"Implemented Categories",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      StringFromCLSID(CATID_SafeForScripting,&oleString);
      WideCharToMultiByte(CP_ACP,0,oleString,-1,szTemp,MAX_PATH,0,0);
      RegCreateKeyEx(keyHandle,szTemp,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);

      RegCreateKeyEx(clsidHandle,"Implemented Categories",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      StringFromCLSID(CATID_SafeForInitializing,&oleString);
      WideCharToMultiByte(CP_ACP,0,oleString,-1,szTemp,MAX_PATH,0,0);
      RegCreateKeyEx(keyHandle,szTemp,0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
#endif    
      RegCreateKeyEx(HKEY_CLASSES_ROOT,OBJECT_NAME[objectIndex],0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegCreateKeyEx(keyHandle,"CurVer",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      sprintf(szTemp,OBJECT_NAME_V[objectIndex]);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szTemp,strlen(szTemp));
    
      RegCreateKeyEx(HKEY_CLASSES_ROOT,OBJECT_NAME_V[objectIndex],0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegCreateKeyEx(keyHandle,"CLSID",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
      RegSetValueEx(keyHandle,NULL,0,REG_SZ,(BYTE *)szCLSID,strlen(szCLSID));
  
      if ( 0 == objectIndex ) {
         RegOpenKeyEx(HKEY_CLASSES_ROOT,"MIME\\Database\\Content Type",0,KEY_CREATE_SUB_KEY,&keyHandle);
         RegCreateKeyEx(keyHandle,"application/electronic-signature",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&keyHandle,&disposition);
         RegSetValueEx(keyHandle,"CLSID",0,REG_SZ,(BYTE *)szCLSID,strlen(szCLSID));
      }

   }

   ICatRegister *pICatRegister;

   rc = CoCreateInstance(CLSID_StdComponentCategoriesMgr,NULL,CLSCTX_ALL,IID_ICatRegister,reinterpret_cast<void **>(&pICatRegister));

   CATID categoryId = CATID_SafeForScripting;

   pICatRegister -> RegisterClassImplCategories(CLSID_CursiVision,1,&categoryId);

   categoryId = CATID_SafeForInitializing;

   pICatRegister -> RegisterClassImplCategories(CLSID_CursiVision,1,&categoryId);

   pICatRegister -> Release();

   return S_OK;
   }
  
  
   STDAPI DllUnregisterServer() {

   CoInitialize(NULL);

#if 0

   ICatRegister *pICatRegister;
   long rc = CoCreateInstance(CLSID_StdComponentCategoriesMgr,NULL,CLSCTX_ALL,IID_ICatRegister,reinterpret_cast<void **>(&pICatRegister));
   CATID categoryId = IID_ICursiVisionBackEnd;
   pICatRegister -> UnRegisterClassImplCategories(CLSID_CursiVisionBackEndPropertyPage,1,&categoryId);
   pICatRegister -> Release();

#endif

   HKEY keyHandle;
   LPOLESTR oleString;
  
   for ( long objectIndex = 0; 1; objectIndex++ ) {

      if ( ! OBJECT_NAME[objectIndex] )
         break;

      char szCLSID[256];

      StringFromCLSID(OBJECT_CLSID[objectIndex],&oleString);

      WideCharToMultiByte(CP_ACP,0,oleString,-1,szCLSID,256,0,0);
  
      RegOpenKeyEx(HKEY_CLASSES_ROOT,"CLSID",0,KEY_CREATE_SUB_KEY,&keyHandle);

      long rc = SHDeleteKey(keyHandle,szCLSID);

      rc = SHDeleteKey(HKEY_CLASSES_ROOT,OBJECT_NAME[objectIndex]);

      rc = SHDeleteKey(HKEY_CLASSES_ROOT,OBJECT_NAME_V[objectIndex]);

   }

   return S_OK;
   }
  
