/*

                       Copyright (c) 2011,2012 Nathan T. Clark

*/

#include "InsertPDF.h"

   static bool okayToSave = false;

   long __stdcall InsertPDF::_IOleObject::_IPropertyPage::QueryInterface(REFIID riid,void **ppv) {
   *ppv = NULL;
   if ( riid == IID_IPropertyPage )
      *ppv = static_cast<IPropertyPage *>(this);
   else
      return pParent -> QueryInterface(riid,ppv);
   AddRef(); 
   return S_OK; 
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPropertyPage::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPropertyPage::Release() {
   return pParent -> Release();
   }
 
 
   HRESULT InsertPDF::_IOleObject::_IPropertyPage::SetPageSite(IPropertyPageSite *pPageSite) {
   return S_OK;
   }

   
   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Activate(HWND hwndParent,const RECT *pRect,BOOL doModal) {

   if ( 0 == nativePropertySheetFrameHandlerRefCount ) {
      hwndPropertySheetFrame = GetParent(hwndParent);
      nativePropertySheetFrameHandler = (WNDPROC)SetWindowLong(hwndPropertySheetFrame,GWL_WNDPROC,(LONG)propertySheetFrameHandler);
   }

   nativePropertySheetFrameHandlerRefCount++;

   resultDisposition *pDisposition = (resultDisposition *)&pParent -> doodleOptionProperties;

   pDisposition -> pParent = pParent;

   if ( CLSID_CursiVisionPropertyPage == theCLSID ) {
      if ( pParent -> hwndDispositionSettings )
         DestroyWindow(pParent -> hwndDispositionSettings);
      pParent -> hwndDispositionSettings = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_DISPOSITION_PROPERTIES),hwndParent,(DLGPROC)InsertPDF::_IOleObject::dispositionSettingsHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndDispositionSettings,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

   if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID ) {
      if ( pParent -> hwndAdditionalBackEnds ) 
         DestroyWindow(pParent -> hwndAdditionalBackEnds);
      pParent -> hwndAdditionalBackEnds = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_BACKENDS),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::additionalBackEndsHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndAdditionalBackEnds,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

#ifdef CURSIVISION_CONTROL_BUILD

   if ( CLSID_CursiVisionControlPropertyPage == theCLSID ) {
      if ( pParent -> hwndControlProperties ) 
         DestroyWindow(pParent -> hwndControlProperties);
      pParent -> hwndControlProperties = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_CURSIVISION_CONTROL_OPTIONS),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::controlPropertiesHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndControlProperties,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

   if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID ) {
      if ( pParent -> hwndTemplateProperties ) 
         DestroyWindow(pParent -> hwndTemplateProperties);
      pParent -> hwndTemplateProperties = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_DOCUMENT_TEMPLATE),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::templateHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndTemplateProperties,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

   if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID ) {
      if ( pParent -> hwndRecognitionProperties ) 
         DestroyWindow(pParent -> hwndRecognitionProperties);
      pParent -> hwndRecognitionProperties = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_CURSIVISION_RECOGNITION),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::recognitionHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndRecognitionProperties,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

   if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID ) {
      if ( pParent -> hwndSigningLocationsProperties ) 
         DestroyWindow(pParent -> hwndSigningLocationsProperties);
      pParent -> hwndSigningLocationsProperties = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_SIGNING_LOCATIONS),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::signingLocationsHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndSigningLocationsProperties,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

   if ( CLSID_CursiVisionFieldsPropertyPage == theCLSID ) {
      if ( pParent -> hwndDataFields ) 
         DestroyWindow(pParent -> hwndDataFields);
      pParent -> hwndDataFields = CreateDialogParam(hModule,MAKEINTRESOURCE(IDD_DATA_FIELDS),(HWND)hwndParent,(DLGPROC)InsertPDF::_IOleObject::fieldsHandlerISpecifyPropertyPageImplementation,(long)pDisposition);
      SetWindowPos(pParent -> hwndDataFields,HWND_TOP,pRect -> left,pRect -> top,pRect -> right - pRect -> left,pRect -> bottom - pRect -> top,SWP_SHOWWINDOW);
      return S_OK;
   }

#endif

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Deactivate() {

   if ( CLSID_CursiVisionPropertyPage == theCLSID ) {
      if ( pParent -> hwndDispositionSettings ) {
         DestroyWindow(pParent -> hwndDispositionSettings);
         pParent -> hwndDispositionSettings = NULL;
      }
   }

   if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID ) {
      if ( pParent -> hwndAdditionalBackEnds ) {
         DestroyWindow(pParent -> hwndAdditionalBackEnds);
         pParent -> hwndAdditionalBackEnds = NULL;
      }
   }

   if ( CLSID_CursiVisionControlPropertyPage == theCLSID ) {
      if ( pParent -> hwndControlProperties) {
         DestroyWindow(pParent -> hwndControlProperties);
         pParent -> hwndControlProperties = NULL;
      }
   }

   if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID ) {
      if ( pParent -> hwndTemplateProperties) {
         DestroyWindow(pParent -> hwndTemplateProperties);
         pParent -> hwndTemplateProperties = NULL;
      }
   }

   if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID ) {
      if ( pParent -> hwndRecognitionProperties) {
         DestroyWindow(pParent -> hwndRecognitionProperties);
         pParent -> hwndRecognitionProperties = NULL;
      }
   }
   
   if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID ) {
      if ( pParent -> hwndSigningLocationsProperties) {
         DestroyWindow(pParent -> hwndSigningLocationsProperties);
         pParent -> hwndSigningLocationsProperties = NULL;
      }
   }

   if ( CLSID_CursiVisionFieldsPropertyPage == theCLSID ) {
      if ( pParent -> hwndDataFields) {
         DestroyWindow(pParent -> hwndDataFields);
         pParent -> hwndDataFields = NULL;
      }
   }

   if ( 0 == --nativePropertySheetFrameHandlerRefCount )
      SetWindowLong(hwndPropertySheetFrame,GWL_WNDPROC,(long)nativePropertySheetFrameHandler);

   return S_OK;
   }



   HRESULT InsertPDF::_IOleObject::_IPropertyPage::GetPageInfo(PROPPAGEINFO *pPageInfo) {

   memset(pPageInfo,0,sizeof(PROPPAGEINFO));

   pPageInfo -> cb = sizeof(PROPPAGEINFO);

   pPageInfo -> pszTitle = (BSTR)CoTaskMemAlloc(128);

   pPageInfo -> pszDocString = NULL;

   memset(pPageInfo -> pszTitle,0,128);

   if ( CLSID_CursiVisionPropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"CursiVision Properties",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 256 + 128 + 64;
      pPageInfo -> size.cy = 256 + 128;

   } else if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"Back-End Processors",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 256 + 128;
      pPageInfo -> size.cy = 512;

   } else if ( CLSID_CursiVisionControlPropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"CursiVision as a Control",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 256 + 128;
      pPageInfo -> size.cy = 512;

   } else if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"Document Template",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 480;
      pPageInfo -> size.cy = 512;

   } else if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"Document Recognition",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 480;
      pPageInfo -> size.cy = 512;

   } else if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID ) {
      MultiByteToWideChar(CP_ACP,0,"Signing Locations",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 480;
      pPageInfo -> size.cy = 512;

   } else {
      MultiByteToWideChar(CP_ACP,0,"Data Fields",-1,(BSTR)pPageInfo -> pszTitle,128);
      pPageInfo -> size.cx = 480;
      pPageInfo -> size.cy = 512;

   }

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::SetObjects(ULONG cObjects,IUnknown** pUnk) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Show(UINT cmdShow) {

   if ( CLSID_CursiVisionPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndDispositionSettings,cmdShow);

   else if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndAdditionalBackEnds,cmdShow);

   else if ( CLSID_CursiVisionControlPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndControlProperties,cmdShow);

   else if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID )
      ShowWindow(pParent -> hwndTemplateProperties,cmdShow);

   else if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndSigningLocationsProperties,cmdShow);

   else if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndRecognitionProperties,cmdShow);

   else if ( CLSID_CursiVisionFieldsPropertyPage == theCLSID )
      ShowWindow(pParent -> hwndDataFields,cmdShow);

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Move(const RECT *prc) {

   if ( CLSID_CursiVisionPropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndDispositionSettings,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID ) 
      SetWindowPos(pParent -> hwndAdditionalBackEnds,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionControlPropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndControlProperties,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndTemplateProperties,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndRecognitionProperties,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndSigningLocationsProperties,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   else if ( CLSID_CursiVisionFieldsPropertyPage == theCLSID )
      SetWindowPos(pParent -> hwndDataFields,HWND_TOP,prc -> left,prc -> top, prc -> right - prc -> left,prc -> bottom - prc -> top,0L);

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::IsPageDirty() {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Apply() {

   pParent -> fire_PropertyChanged();

   if ( ! okayToSave )
      return S_OK;

   okayToSave = false;

   PSHNOTIFY notify = {0};

   notify.hdr.code = PSN_APPLY;
   notify.lParam = 1L;

//   if ( CLSID_CursiVisionPropertyPage == theCLSID ) 
      SendMessage(pParent -> hwndDispositionSettings,WM_NOTIFY,0L,(LPARAM)&notify);

//   else if ( CLSID_CursiVisionBackEndPropertyPage == theCLSID )
      SendMessage(pParent -> hwndAdditionalBackEnds,WM_NOTIFY,0L,(LPARAM)&notify);

//   else if ( CLSID_CursiVisionControlPropertyPage == theCLSID )
      SendMessage(pParent -> hwndControlProperties,WM_NOTIFY,0L,(LPARAM)&notify);

//   else if ( CLSID_CursiVisionTemplatePropertyPage == theCLSID )
      SendMessage(pParent -> hwndTemplateProperties,WM_NOTIFY,0L,(LPARAM)&notify);

//   else if ( CLSID_CursiVisionRecognitionPropertyPage == theCLSID )
      SendMessage(pParent -> hwndRecognitionProperties,WM_NOTIFY,0L,(LPARAM)&notify);

//   else if ( CLSID_CursiVisionSigningLocationsPropertyPage == theCLSID )
      SendMessage(pParent -> hwndSigningLocationsProperties,WM_NOTIFY,0L,(LPARAM)&notify);

      SendMessage(pParent -> hwndDataFields,WM_NOTIFY,0L,(LPARAM)&notify);

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::Help(LPCOLESTR pszHelpDir) {
   return E_FAIL;
   }


   HRESULT InsertPDF::_IOleObject::_IPropertyPage::TranslateAccelerator(MSG* pMsg) {
   return S_FALSE;
   }

//
//NTC: 02-08-2012. This is a total bullshit hack that is necessary because the MS documentation
// cannot bother to say anywhere how on earth to tell if the user pressed OK, or Cancel - as if
// nobody would ever want to know this absolutely obvious thing to need to know !?!
//
   LRESULT CALLBACK InsertPDF::_IOleObject::propertySheetFrameHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( msg == WM_COMMAND ) {
      switch ( LOWORD(wParam ) ) {
      case IDOK:
         okayToSave = true;
         break;
      case IDCANCEL:
         okayToSave = false;
         break;
      }
   }
   return CallWindowProc(nativePropertySheetFrameHandler,hwnd,msg,wParam,lParam);
   }
   