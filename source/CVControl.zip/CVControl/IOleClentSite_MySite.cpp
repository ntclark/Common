
#include "InsertPDF.h"

   long __stdcall InsertPDF::_IOleClientSite_MySite::QueryInterface(REFIID riid,void **ppv) {

   if ( IID_IUnknown == riid ) 
      return pParent -> QueryInterface(riid,ppv);
   else

   if ( IID_IOleClientSite == riid ) 
      *ppv = static_cast<IOleClientSite*>(this);
   else

   if ( IID_IOleInPlaceSite == riid ) 
      return pIOleInPlaceSite -> QueryInterface(riid,ppv);
   else

   if ( IID_IOleInPlaceFrame == riid ) 
      return pIOleInPlaceFrame -> QueryInterface(riid,ppv);
   else

      return pParent -> QueryInterface(riid,ppv);

   AddRef();

   return S_OK;
   }

   unsigned long __stdcall InsertPDF::_IOleClientSite_MySite::AddRef() {
   return ++refCount;
   }

   unsigned long __stdcall InsertPDF::_IOleClientSite_MySite::Release() {
   return --refCount;
   }


   HRESULT InsertPDF::_IOleClientSite_MySite::SaveObject() {
   return S_OK;
   }

   
   HRESULT InsertPDF::_IOleClientSite_MySite::GetMoniker(DWORD,DWORD,IMoniker**) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleClientSite_MySite::GetContainer(IOleContainer **) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleClientSite_MySite::ShowObject() {
   ShowWindow(hwndMainFrame,SW_SHOW);
   return S_OK;
   }


   HRESULT InsertPDF::_IOleClientSite_MySite::OnShowWindow(BOOL) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleClientSite_MySite::RequestNewObjectLayout() {
   return S_OK;
   }