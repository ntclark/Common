/*
                       Copyright (c) 2009,2010,2011,2012,2013,2014 Nathan T. Clark
*/

#include "insertPDF.h"

#include "dispositionSettingsDefines.h"

#define OBJECT_WITH_PROPERTIES InsertPDF::_IOleObject

static InsertPDF::doodleOptionProperties *pDoodleOptionProps = NULL;

#define DOODLE_PROPERTIES_PTR pDoodleOptionProps = &pObject -> doodleOptionProperties;

#include "fieldsHandlerDefines.h"

   LRESULT CALLBACK InsertPDF::_IOleObject::fieldsHandlerISpecifyPropertyPageImplementation(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( WM_INITDIALOG == msg ) {
      PROPSHEETPAGE propSheetPage = {0};
      propSheetPage.lParam = lParam;
      return fieldsHandler(hwnd,msg,wParam,(long)&propSheetPage);
   }
   return fieldsHandler(hwnd,msg,wParam,lParam);
   }

   LRESULT CALLBACK InsertPDF::_IOleObject::fieldsHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {

#include "fieldsHandlerBody.cpp"

   return LRESULT(FALSE);
   }

#include "fieldsHandlerSupport.cpp"