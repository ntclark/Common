
#include "InsertPDF.h"

   extern BYTE *pRestoreControlSettings;

   static char szMessage[1024];

   BOOL InsertPDF::_IOleObject::findProfile() {

   memset(szProfile,0,sizeof(szProfile));

   if ( ! pRestoreControlSettings ) {
      pRestoreControlSettings = new BYTE[oleObjectPropertiesSize];
      memcpy(pRestoreControlSettings,pOleObjectProperties,oleObjectPropertiesSize);
   }

   char szOutlinesFile[MAX_PATH];

   strcpy(szOutlinesFile,_tempnam(NULL,NULL));
   
   long countEntries = pParent -> pICursiVisionServices -> generateOutlines(pParent -> szActiveDocument,szOutlinesFile,1,1);

   if ( 0 == countEntries ) {
      DeleteFile(szOutlinesFile);
      return FALSE;
   }

   RECT *pPDFEntries = NULL;
   long *pPDFPages = NULL;
   char *pTextValues = NULL;

   bool wereEntries = pParent -> pICursiVisionServices -> readOutlines(&pPDFEntries,&pPDFPages,pParent -> szActiveDocument,szOutlinesFile,&pTextValues,&countEntries,NULL,NULL);

   if ( ! wereEntries ) {
      if ( pPDFEntries )
         delete [] pPDFEntries;
      if ( pPDFPages )
         delete [] pPDFPages;
      if ( pTextValues )
         delete [] pTextValues;
      DeleteFile(szOutlinesFile);
      return FALSE;
   }

   char szCurrentDirectory[MAX_PATH];

   GetCurrentDirectory(MAX_PATH,szCurrentDirectory);

   if ( szRepository[0] )
      SetCurrentDirectory(szRepository);

   _IOleObject *pOther = pParent -> ppIOleObject[1];

   if ( 2 > pParent -> oleObjectCount ) {
      pParent -> ppIOleObject[1] = new _IOleObject(pParent);
      pOther = pParent -> ppIOleObject[1];
      pParent -> oleObjectCount = 2;
      pOther -> AddRef();
   }

   IPersistStreamInit *pIPersistStreamInit = NULL;

   pOther -> QueryInterface(IID_IPersistStreamInit,reinterpret_cast<void **>(&pIPersistStreamInit));

   WIN32_FIND_DATA findFileData = {0};

   HANDLE hFindFiles = FindFirstFile("*.cvProfile",&findFileData);

   bool wasFound = false;

   long countCandidates = 0L;

   if ( INVALID_HANDLE_VALUE != hFindFiles ) do {

      countCandidates++;

      IStorage *pIStorage = NULL;
      IStream *pIStream = NULL;

      BSTR bstrProfile = SysAllocStringLen(NULL,MAX_PATH);

      MultiByteToWideChar(CP_ACP,0,findFileData.cFileName,-1,bstrProfile,MAX_PATH);

      HRESULT hr = StgOpenStorageEx(bstrProfile,STGM_READWRITE | STGM_SHARE_EXCLUSIVE,STGFMT_STORAGE,0,NULL,NULL,IID_IStorage,reinterpret_cast<void **>(&pIStorage));

      if ( S_OK == hr ) {
         hr = pIStorage -> OpenStream(L"CV Document Profile",0,STGM_READWRITE | STGM_SHARE_EXCLUSIVE,0,&pIStream);
         if ( S_OK == hr ) {
            hr = pIPersistStreamInit -> Load(pIStream);
         } else {
            sprintf(szMessage,"The system was not able to find the settings stream in the file:\n\n\t%s\n\nThe windows error code is: %x",findFileData.cFileName,hr);
            MessageBox(NULL,szMessage,"Error",MB_ICONEXCLAMATION | MB_TOPMOST);
         }
      } else {
         sprintf(szMessage,"The system was not able to open the storage object in the file:\n\n\t%s\n\nThe windows error code is: %x",findFileData.cFileName,hr);
         MessageBox(NULL,szMessage,"Error",MB_ICONEXCLAMATION | MB_TOPMOST);
      }

      if ( pIStream )
         pIStream -> Release();

      if ( pIStorage )
         pIStorage -> Release();

      if ( S_OK == hr )  {

         if ( 0L == pOther -> match(countEntries,pPDFEntries,pPDFPages,pTextValues) ) {
            SysFreeString(bstrProfile);
            continue;
         }

         strcpy(szProfile,findFileData.cFileName);

         loadProfile();

         wasFound = true;

         SysFreeString(bstrProfile);

         break;

      }

      SysFreeString(bstrProfile);

   } while ( FindNextFile(hFindFiles,&findFileData) );

   if ( pIPersistStreamInit )
      pIPersistStreamInit -> Release();

   if ( pPDFEntries )
      delete [] pPDFEntries;
   if ( pPDFPages )
      delete [] pPDFPages;
   if ( pTextValues )
      delete [] pTextValues;

   DeleteFile(szOutlinesFile);

   SetCurrentDirectory(szCurrentDirectory);

   if ( ! wasFound )
      memcpy(pOleObjectProperties,pRestoreControlSettings,oleObjectPropertiesSize);
   
   if ( 0 == countCandidates ) {
#if 0
      sprintf(szMessage,"CursiVision was not able to find any Document Profiles in the repository:\n\n\t%s\n\nPlease ensure you have appropriate rights to read files in that location.",szRepository);
      MessageBox(NULL,szMessage,"Error",MB_ICONEXCLAMATION | MB_TOPMOST);
#endif
   }

   return wasFound;
   }


   BOOL InsertPDF::_IOleObject::loadProfile() {

   char szCurrentDirectory[MAX_PATH];

   GetCurrentDirectory(MAX_PATH,szCurrentDirectory);

   if ( szRepository[0] )
      SetCurrentDirectory(szRepository);

   FILE *fProfile = fopen(szProfile,"rb");
   if ( ! fProfile ) {
      SetCurrentDirectory(szCurrentDirectory);
      return FALSE;
   }

   IStorage *pIStorage = NULL;
   IStream *pIStream = NULL;

   BSTR bstrProfile = SysAllocStringLen(NULL,MAX_PATH);

   MultiByteToWideChar(CP_ACP,0,szProfile,-1,bstrProfile,MAX_PATH);

   HRESULT hr = StgOpenStorageEx(bstrProfile,STGM_READWRITE | STGM_SHARE_EXCLUSIVE,STGFMT_STORAGE,0,NULL,NULL,IID_IStorage,reinterpret_cast<void **>(&pIStorage));

   if ( S_OK == hr ) {
      hr = pIStorage -> OpenStream(L"CV Document Profile",0,STGM_READWRITE | STGM_SHARE_EXCLUSIVE,0,&pIStream);
      if ( S_OK == hr ) {
         hr = pIPersistStreamInit -> Load(pIStream);
      }          
   }    

   if ( pIStream )
      pIStream -> Release();

   if ( pIStorage )
      pIStorage -> Release();

   SysFreeString(bstrProfile);

   SetCurrentDirectory(szCurrentDirectory);

   return (S_OK == hr);
   }


   long InsertPDF::_IOleObject::match(long countEntries,RECT *pPDFEntries,long *pPDFPages,char *pTextValues) {

   if ( ! expectedRects[0].left )
      return 0;

   RECT *pr = expectedRects;
   char *pText = expectedText;
   long *pExpectedPage = expectedPage;

   while ( pr -> left ) {

      RECT *pProfileRect = pPDFEntries;
      char *pProfileText = pTextValues;
      long *pProfilePage = pPDFPages;

      RECT rcTest;

      memcpy(&rcTest,pr,sizeof(RECT));

      if ( rcTest.bottom < rcTest.top ) {
         long t = rcTest.bottom;
         rcTest.bottom = rcTest.top;
         rcTest.top = t;
      }

      bool matchFound = false;

      char szCompositeText[2048];

      memset(szCompositeText,0,sizeof(szCompositeText));

      for ( long k = 0; k < countEntries; k++, pProfileRect++, pProfilePage++, pProfileText += 33 ) {

         if ( *pProfilePage != *pExpectedPage )
            continue;

         RECT rcSource;

         memcpy(&rcSource,pProfileRect,sizeof(RECT));

         if ( rcSource.bottom < rcSource.top ) {
            long t = rcSource.bottom;
            rcSource.bottom = rcSource.top;
            rcSource.top = t;
         }

         if ( rcSource.left >= rcTest.left && rcSource.right <= rcTest.right &&
                  rcSource.top >= rcTest.top && rcSource.bottom <= rcTest.bottom ) {

            long n = max(0,2047 - strlen(szCompositeText));

            if ( n > 0 )
               strncpy(szCompositeText + strlen(szCompositeText),pProfileText,n);

            matchFound = true;

            continue;

         } else {

            if ( abs(pr -> left - pProfileRect -> left) > PDF_RECT_LEFT_SLOP )
               continue;

            if ( abs(pr -> top - pProfileRect -> top) > PDF_RECT_TOP_SLOP || abs(pr -> bottom - pProfileRect -> bottom) > PDF_RECT_TOP_SLOP )
               continue;

         }

         if ( 0 == strncmp(pProfileText,pText,strlen(pText)) ) {
            matchFound = true;
            break;
         }

      }

      if ( ! matchFound ) 
         return 0;

      if ( szCompositeText[0] ) {
         if ( strncmp(szCompositeText,pText,strlen(pText)) ) {
            return 0;
         }
      }

      pr++;
      pText += 33;
      pExpectedPage++;

   }

   return 1L;
   }