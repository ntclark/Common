/*
                       Copyright (c) 2009,2010,2011,2012 Nathan T. Clark
*/

#include "insertPDF.h"

extern "C" void disableAll(HWND hwnd,long *pExceptions);
extern "C" void enableAll(HWND hwnd,long *pExceptions);

#define OBJECT_WITH_PROPERTIES InsertPDF::_IOleObject

#define CURSIVISION_SERVICES_INTERFACE pInsertPDF -> pICursiVisionServices

#define ALL_BACKENDS_LIST pInsertPDF -> allBackEnds

#define IS_CURSIVISION_CONTROL_HANDLER

#define PARENT_OBJECT_PREFERRED_SETTINGS_FILE_NAME ""

   struct buttonPair {
      HWND hwndList,hwndUse,hwndProperties,hwndOrder;
      GUID objectId;
      char szSettingsFileName[MAX_PATH];
      GUID instanceId;
      IUnknown *pIUnknown_Object;
   };

   static buttonPair buttonPairs[32];

   static HWND hwndTopList = NULL;
   static HWND hwndBottomList = NULL;

   static long nativeTopListHeight = 0;
   static long nativeTopListWidth = 0;
   static long nativeWidth = 0;
   static long nativeHeight = 0;
   static long countAvailableBackEnds = 0;

   LRESULT CALLBACK InsertPDF::_IOleObject::additionalBackEndsHandlerISpecifyPropertyPageImplementation(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( WM_INITDIALOG == msg ) {
      PROPSHEETPAGE propSheetPage = {0};
      propSheetPage.lParam = lParam;
      return additionalBackEndsHandler(hwnd,msg,wParam,(long)&propSheetPage);
   }
   return additionalBackEndsHandler(hwnd,msg,wParam,lParam);
   }

   LRESULT CALLBACK InsertPDF::_IOleObject::additionalBackEndsHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {

   resultDisposition *p = (resultDisposition *)GetWindowLong(hwnd,GWL_USERDATA);

#include "additionalBackEndsBody.cpp"

   return LRESULT(FALSE);
   }

#include "additionalBackEnds_ListViewHandler.cpp"
