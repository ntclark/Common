/*
                       Copyright (c) 2009,2010,2011,2012 Nathan T. Clark
*/

#include "insertPDF.h"

#define OBJECT_WITH_PROPERTIES InsertPDF::_IOleObject

#include "recognitionPropertiesDefines.h"

   LRESULT CALLBACK InsertPDF::_IOleObject::recognitionHandlerISpecifyPropertyPageImplementation(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( WM_INITDIALOG == msg ) {
      PROPSHEETPAGE propSheetPage = {0};
      propSheetPage.lParam = lParam;
      return recognitionHandler(hwnd,msg,wParam,(long)&propSheetPage);
   }
   return recognitionHandler(hwnd,msg,wParam,lParam);
   }

   LRESULT CALLBACK InsertPDF::_IOleObject::recognitionHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {

#include "recognitionPropertiesBody.cpp"

   return LRESULT(FALSE);
   }

#include "recognitionPropertiesSupport.cpp"