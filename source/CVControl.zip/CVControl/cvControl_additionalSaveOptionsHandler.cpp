/*
                       Copyright (c) 2009,2010,2011,2012 Nathan T. Clark
*/

#include "insertPDF.h"

#define OBJECT_WITH_PROPERTIES InsertPDF::_IOleObject

#define IS_CURSIVISION_CONTROL_HANDLER

#include "additionalSaveOptionsBody.cpp"
