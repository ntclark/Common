/*

                       Copyright (c) 2009,2010,2011,2012,2013,2014 Nathan T. Clark

*/

#include "insertPDF.h"


   long __stdcall InsertPDF::_IOleObject::_ISpecifyPropertyPages::QueryInterface(REFIID riid,void **ppv) {

   *ppv = NULL; 

   if ( riid == IID_ISpecifyPropertyPages )
      *ppv = static_cast<ISpecifyPropertyPages *>(this);
   else
 
      return pParent -> QueryInterface(riid,ppv);
 
   AddRef();
   return S_OK; 
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_ISpecifyPropertyPages::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_ISpecifyPropertyPages::Release() {
   return pParent -> Release();
   }


   HRESULT InsertPDF::_IOleObject::_ISpecifyPropertyPages::GetPages(CAUUID *pCAUUID) {

   if ( ! pCAUUID )
      return E_POINTER;

#ifdef CURSIVISION_CONTROL_BUILD
   pCAUUID -> cElems = 7;
#else
   pCAUUID -> cElems = 2;
#endif

   pCAUUID -> pElems = reinterpret_cast<GUID *>(CoTaskMemAlloc(pCAUUID -> cElems * sizeof(GUID)));

   memset(pCAUUID -> pElems,0,pCAUUID -> cElems * sizeof(GUID));

   pCAUUID -> pElems[0] = CLSID_CursiVisionPropertyPage;
   pCAUUID -> pElems[1] = CLSID_CursiVisionBackEndPropertyPage;

#ifdef CURSIVISION_CONTROL_BUILD

   pCAUUID -> pElems[2] = CLSID_CursiVisionControlPropertyPage;
   pCAUUID -> pElems[3] = CLSID_CursiVisionTemplatePropertyPage;
   pCAUUID -> pElems[4] = CLSID_CursiVisionRecognitionPropertyPage;
   pCAUUID -> pElems[5] = CLSID_CursiVisionSigningLocationsPropertyPage;
   pCAUUID -> pElems[6] = CLSID_CursiVisionFieldsPropertyPage;

#endif

   return S_OK;
   }