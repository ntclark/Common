/*

                       Copyright (c) 2011 Nathan T. Clark

*/

#include "InsertPDF.h"

   long __stdcall InsertPDF::_IOleObject::_IPersistStorage::QueryInterface(REFIID riid,void **ppv) {

   *ppv = NULL;

   if ( IID_IPersistStorage == riid )
      *ppv = static_cast<IPersistStorage *>(this);
   else

      return pParent -> QueryInterface(riid,ppv);

   AddRef();

   return S_OK;
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPersistStorage::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPersistStorage::Release() {
   return pParent -> Release();
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::GetClassID(CLSID *pcid) {
   memcpy(pcid,&CLSID_CursiVision,sizeof(GUID));
   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::IsDirty() {
   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::InitNew(IStorage *pIStorage) {
   IGPropertiesClient *p = NULL;
   pParent -> pParent -> QueryInterface(IID_IGPropertiesClient,reinterpret_cast<void **>(&p));
   p -> InitNew();
   p -> Release();
   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::Load(IStorage *pIStorage) {

   IStream *pIStream;

   HRESULT hr = pIStorage -> OpenStream(L"CursiVision",0,STGM_READ | STGM_SHARE_EXCLUSIVE,0,&pIStream);

   if ( S_OK != hr )
      return E_FAIL;

   ULONG cbRead = sizeof(resultDisposition);

   hr = pIStream -> Read((BYTE *)&pParent -> pParent -> processingDisposition,cbRead,&cbRead);

   pIStream -> Release();

   IGPropertiesClient *p = NULL;
   pParent -> pParent -> QueryInterface(IID_IGPropertiesClient,reinterpret_cast<void **>(&p));
   p -> Loaded();
   p -> Release();

   if ( pIStorage_Cached )
      pIStorage_Cached -> Release();
   pIStorage_Cached = pIStorage;
   pIStorage_Cached -> AddRef();

   pParent -> pParent -> isRestored = true;

   pParent -> SetClientSite(pParent -> pIOleClientSite_MySite);

   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::Save(IStorage *pIStorage,BOOL sameAsLoad) {

   IStream *pIStream;

   HRESULT hr = pIStorage -> DestroyElement(L"CursiVision");

   hr = pIStorage -> CreateStream(L"CursiVision",STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,0,0,&pIStream);

   noScribble = true;

   ULONG cbWritten = sizeof(resultDisposition);

   hr = pIStream -> Write((BYTE *)&pParent -> pParent -> processingDisposition,cbWritten,&cbWritten);

   pIStream -> Release();

   if ( ! pIStorage_Cached )
      return S_OK;

   hr = pIStorage_Cached -> DestroyElement(L"CursiVision");
   hr = pIStorage_Cached -> CreateStream(L"CursiVision",STGM_READWRITE | STGM_SHARE_EXCLUSIVE | STGM_CREATE,0,0,&pIStream);
   cbWritten = sizeof(resultDisposition);
   hr = pIStream -> Write((BYTE *)&pParent -> pParent -> processingDisposition,cbWritten,&cbWritten);
   pIStream -> Release();

   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::SaveCompleted(IStorage *) {
   noScribble = false;
   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStorage::HandsOffStorage() {
   return S_OK;
   }
