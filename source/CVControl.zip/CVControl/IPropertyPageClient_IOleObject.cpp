/*

                       Copyright (c) 2009,2010,2011,2012,2013,2014 Nathan T. Clark

*/

#include "insertPDF.h"

   long __stdcall InsertPDF::_IOleObject::_IGPropertyPageClient::QueryInterface(REFIID riid,void **ppv) {
   *ppv = NULL; 
 
   if ( riid == IID_IUnknown )
      *ppv = static_cast<IUnknown*>(this); 
   else

   if ( riid == IID_IDispatch )
      *ppv = this;
   else

   if ( riid == IID_IGPropertyPageClient )
      *ppv = static_cast<IGPropertyPageClient*>(this);
   else
 
      return pParent -> QueryInterface(riid,ppv);
 
   static_cast<IUnknown*>(*ppv) -> AddRef();
  
   return S_OK; 
   }
 
   unsigned long __stdcall InsertPDF::_IOleObject::_IGPropertyPageClient::AddRef() {
   return 1;
   }
 
   unsigned long __stdcall InsertPDF::_IOleObject::_IGPropertyPageClient::Release() {
   return 1;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::BeforeAllPropertyPages() {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::GetPropertyPagesInfo(long *pCntPages,SAFEARRAY** thePageNames,SAFEARRAY** theHelpDirs,SAFEARRAY** pSize) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::CreatePropertyPage(long pageNumber,long hwndParent,RECT* pRect,BOOL fModal,long* pHwnd) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::Apply() {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::IsPageDirty(long pageNumber,BOOL* isDirty) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::Help(BSTR bstrHelpDir) {
   return  S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::TranslateAccelerator(long,long* pResult) {
   *pResult = S_FALSE;
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::AfterAllPropertyPages(BOOL userCanceled) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::DestroyPropertyPage(long index) {
   return S_OK;
   }



   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::GetPropertySheetHeader(void *pv) {

   if ( ! pv )
      return E_POINTER;

   PROPSHEETHEADER *pHeader = reinterpret_cast<PROPSHEETHEADER *>(pv);

   pHeader -> dwFlags = PSH_PROPSHEETPAGE | PSH_NOCONTEXTHELP;
   pHeader -> hInstance = hModule;
   pHeader -> pszIcon = 0L;
   pHeader -> pszCaption = "CursiVision Setup";
   pHeader -> pfnCallback = NULL;

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::get_PropertyPageCount(long *pCount) {
   if ( ! pCount )
      return E_POINTER;
   *pCount = 6L;
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IGPropertyPageClient::GetPropertySheets(void *pPages) {

   if ( ! pPages )
      return E_POINTER;

   resultDisposition *pDisposition = (resultDisposition *)&pParent -> doodleOptionProperties;

   pDisposition -> pParent = pParent;

   PROPSHEETPAGE *pPropSheetPages = reinterpret_cast<PROPSHEETPAGE *>(pPages);

   pPropSheetPages[0].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[0].dwFlags = PSP_USETITLE;
   pPropSheetPages[0].hInstance = hModule;
   pPropSheetPages[0].pszTemplate = MAKEINTRESOURCE(IDD_DISPOSITION_PROPERTIES);
   pPropSheetPages[0].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::dispositionSettingsHandler;
   pPropSheetPages[0].pszTitle = DISPOSITION_TITLE;
   pPropSheetPages[0].lParam = (long)pDisposition;
   pPropSheetPages[0].pfnCallback = NULL;

   pPropSheetPages[1].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[1].dwFlags = PSP_USETITLE;
   pPropSheetPages[1].hInstance = hModule;
   pPropSheetPages[1].pszTemplate = MAKEINTRESOURCE(IDD_BACKENDS);
   pPropSheetPages[1].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::additionalBackEndsHandler;
   pPropSheetPages[1].pszTitle = "Tool Box";
   pPropSheetPages[1].lParam = (long)pDisposition;
   pPropSheetPages[1].pfnCallback = NULL;

   pPropSheetPages[2].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[2].dwFlags = PSP_USETITLE;
   pPropSheetPages[2].hInstance = hModule;
   pPropSheetPages[2].pszTemplate = MAKEINTRESOURCE(IDD_DOCUMENT_TEMPLATE);
   pPropSheetPages[2].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::templateHandler;
   pPropSheetPages[2].pszTitle = "Template Document";
   pPropSheetPages[2].lParam = (long)pDisposition;
   pPropSheetPages[2].pfnCallback = NULL;

   pPropSheetPages[3].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[3].dwFlags = PSP_USETITLE;
   pPropSheetPages[3].hInstance = hModule;
   pPropSheetPages[3].pszTemplate = MAKEINTRESOURCE(IDD_CURSIVISION_RECOGNITION);
   pPropSheetPages[3].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::recognitionHandler;
   pPropSheetPages[3].pszTitle = "Document Recognition";
   pPropSheetPages[3].lParam = (long)pDisposition;
   pPropSheetPages[3].pfnCallback = NULL;

   pPropSheetPages[4].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[4].dwFlags = PSP_USETITLE;
   pPropSheetPages[4].hInstance = hModule;
   pPropSheetPages[4].pszTemplate = MAKEINTRESOURCE(IDD_SIGNING_LOCATIONS);
   pPropSheetPages[4].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::signingLocationsHandler;
   pPropSheetPages[4].pszTitle = "Signing Locations";
   pPropSheetPages[4].lParam = (long)pDisposition;
   pPropSheetPages[4].pfnCallback = NULL;

   pPropSheetPages[5].dwSize = sizeof(PROPSHEETPAGE);
   pPropSheetPages[5].dwFlags = PSP_USETITLE;
   pPropSheetPages[5].hInstance = hModule;
   pPropSheetPages[5].pszTemplate = MAKEINTRESOURCE(IDD_DATA_FIELDS);
   pPropSheetPages[5].pfnDlgProc = (DLGPROC)InsertPDF::_IOleObject::fieldsHandler;
   pPropSheetPages[5].pszTitle = "Data Fields";
   pPropSheetPages[5].lParam = (long)pDisposition;
   pPropSheetPages[5].pfnCallback = NULL;

   return S_OK;
   }