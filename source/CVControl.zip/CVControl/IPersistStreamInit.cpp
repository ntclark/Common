/*

                       Copyright (c) 2011,2012 Nathan T. Clark

*/

#include "InsertPDF.h"

   long __stdcall InsertPDF::_IOleObject::_IPersistStreamInit::QueryInterface(REFIID riid,void **ppv) {

   *ppv = NULL;

   if ( IID_IPersistStreamInit == riid )
      *ppv = static_cast<IPersistStreamInit *>(this);
   else

      return pParent -> QueryInterface(riid,ppv);

   AddRef();

   return S_OK;
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPersistStreamInit::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IPersistStreamInit::Release() {
   return pParent -> Release();
   }


   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::GetClassID(CLSID *pcid) {
   memcpy(pcid,&CLSID_CursiVision,sizeof(GUID));
   return S_OK;
   }


   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::IsDirty() {
   return S_OK;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::Load(IStream *pIStream) {

   if ( pParent -> pTemplateDocument ) {
      delete pParent -> pTemplateDocument;
      pParent -> pTemplateDocument = NULL;
   }

   ULONG cbRead = pParent -> oleObjectPropertiesSize;

   HRESULT rc = pIStream -> Read(pParent -> pOleObjectProperties,cbRead,&cbRead);

   pParent -> pParent -> isRestored = true;

   struct resultDisposition *pDisposition = (resultDisposition *)&pParent -> doodleOptionProperties;

   for ( long k = 0; k < pDisposition -> countBackEnds; k++ ) {

      cbRead = sizeof(GUID);

      rc = pIStream -> Read((BYTE *)&pDisposition -> backEndInstanceIds[k],cbRead,&cbRead);

      if ( S_OK != rc )
         break;

      HRESULT rc = CoCreateInstance(pDisposition -> backEndGUIDS[k],NULL,CLSCTX_INPROC_SERVER,IID_IUnknown,reinterpret_cast<void **>(&pParent -> ppIUnknownBackEnds[k]));

      if ( S_OK != rc )
         continue;

      ICursiVisionBackEnd *pICursiVisionBackEnd = NULL;
      rc = pParent -> ppIUnknownBackEnds[k] -> QueryInterface(IID_ICursiVisionBackEnd,reinterpret_cast<void **>(&pICursiVisionBackEnd));
      if ( S_OK == rc ) {
         pICursiVisionBackEnd -> put_PropertiesFileName(L"");
         pICursiVisionBackEnd -> Release();
      }

      IPersistStreamInit *pIPersistStreamInit = NULL;

      rc = pParent -> ppIUnknownBackEnds[k] -> QueryInterface(IID_IPersistStreamInit,reinterpret_cast<void **>(&pIPersistStreamInit));

      if ( S_OK != rc ) 
         continue;

      pIPersistStreamInit -> Load(pIStream);

      pIPersistStreamInit -> Release();

   }

   pParent -> pTemplateDocument = new templateDocument(pInsertPDF -> pICursiVisionServices,NULL,pParent -> szTemplateDocumentName,pParent -> expectedRects,pParent -> expectedText);

   pParent -> pTemplateDocument -> openDocument();

   return rc;
   }
 
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::Save(IStream *pIStream,BOOL clearDirty) {

   ULONG cbWritten = pParent -> oleObjectPropertiesSize;

   HRESULT rc = pIStream -> Write(pParent -> pOleObjectProperties,cbWritten,&cbWritten);

   struct resultDisposition *pDisposition = (resultDisposition *)&pParent -> doodleOptionProperties;

   for ( long k = 0; k < pDisposition -> countBackEnds; k++ ) {

      cbWritten = sizeof(GUID);

      rc = pIStream -> Write((BYTE *)&pDisposition -> backEndInstanceIds[k],cbWritten,&cbWritten);

      if ( ! pParent -> ppIUnknownBackEnds[k] )
         continue;

      IPersistStreamInit *pIPersistStreamInit = NULL;

      rc = pParent -> ppIUnknownBackEnds[k] -> QueryInterface(IID_IPersistStreamInit,reinterpret_cast<void **>(&pIPersistStreamInit));

      if ( S_OK != rc ) 
         continue;

      pIPersistStreamInit -> Save(pIStream,clearDirty);

      pIPersistStreamInit -> Release();

   }

   return rc;
   }


   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::GetSizeMax(ULARGE_INTEGER *pb) {

   pb -> QuadPart = sizeof(struct resultDisposition) + pParent -> oleObjectPropertiesSize;

   struct resultDisposition *pDisposition = (resultDisposition *)&pParent -> doodleOptionProperties;

   for ( long k = 0; k < pDisposition -> countBackEnds; k++ ) {

      if ( ! pParent -> ppIUnknownBackEnds[k] )
         continue;

      pb -> QuadPart += sizeof(GUID);

      IPersistStreamInit *pIPersistStreamInit = NULL;

      HRESULT rc = pParent -> ppIUnknownBackEnds[k] -> QueryInterface(IID_IPersistStreamInit,reinterpret_cast<void **>(&pIPersistStreamInit));

      if ( S_OK != rc ) 
         continue;

      ULARGE_INTEGER additional;

      pIPersistStreamInit -> GetSizeMax(&additional);

      pb -> QuadPart += additional.QuadPart;

      pIPersistStreamInit -> Release();

   }

   return S_OK;
   }
 
   STDMETHODIMP InsertPDF::_IOleObject::_IPersistStreamInit::InitNew() {
   memset(pParent -> pOleObjectProperties,0,pParent -> oleObjectPropertiesSize);
   memset(pParent -> ppIUnknownBackEnds,0,sizeof(pParent -> ppIUnknownBackEnds));
   return S_OK;
   }