/*

                       Copyright (c) 2011,2012 Nathan T. Clark

*/
#include <windows.h>

#include <olectl.h>

#include "InsertPDF.h"


   long __stdcall InsertPDF::_IOleObject::_IQuickActivate::QueryInterface(REFIID riid,void **ppv) {
 
   if ( IID_IQuickActivate == riid )
      *ppv = static_cast<IQuickActivate *>(this); 
   else
      return pParent -> QueryInterface(riid,ppv);
   AddRef();
   return S_OK; 
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IQuickActivate::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IQuickActivate::Release() {
   return pParent -> Release();
   }


   HRESULT InsertPDF::_IOleObject::_IQuickActivate::QuickActivate(QACONTAINER* qaContainer,QACONTROL* qaControl) {

   DWORD dwDummy;
   pParent -> Advise(qaContainer -> pAdviseSink,&dwDummy);

   if ( qaContainer -> pAdviseSink )
      pParent -> pIViewObjectEx -> SetAdvise(DVASPECT_CONTENT,0,qaContainer -> pAdviseSink);

   qaControl -> cbSize = sizeof(QACONTROL);

   qaControl -> dwPointerActivationPolicy = 0xFFFF;

   pParent -> pIViewObjectEx -> GetViewStatus(&qaControl -> dwViewStatus);

   pParent -> GetMiscStatus(DVASPECT_CONTENT, &qaControl -> dwMiscStatus);

   pParent -> pIOleClientSite_MySite = qaContainer -> pClientSite;

   if ( pParent -> pIOleClientSite_MySite )
      pParent -> pIOleClientSite_MySite -> AddRef();

   pParent -> pParent -> essentialInitialization();

   pParent -> pParent -> initialize(false);

   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IQuickActivate::SetContentExtent(SIZEL* pSizel) {
   return S_OK;
   }


   HRESULT InsertPDF::_IOleObject::_IQuickActivate::GetContentExtent(SIZEL* pSizel) {
   return S_OK;
   }