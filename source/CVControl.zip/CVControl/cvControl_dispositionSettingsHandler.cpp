/*
                       Copyright (c) 2009,2010,2011 Nathan T. Clark
*/

#include "insertPDF.h"

#include <shellapi.h>
#include <shTypes.h>
#include <shlobj.h>

#include <pshpack1.h>

typedef struct DLGTEMPLATEEX {
    WORD dlgVer;
    WORD signature;
    DWORD helpID;
    DWORD exStyle;
    DWORD style;
    WORD cDlgItems;
    short x;
    short y;
    short cx;
    short cy;
} DLGTEMPLATEEX, *LPDLGTEMPLATEEX;

#include <poppack.h>

#define OBJECT_WITH_PROPERTIES InsertPDF::_IOleObject

#include "dispositionSettingsDefines.h"

#define IS_CURSIVISION_CONTROL_HANDLER

   BYTE *pKeep = NULL;

   LRESULT CALLBACK InsertPDF::_IOleObject::dispositionSettingsHandlerISpecifyPropertyPageImplementation(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( WM_INITDIALOG == msg ) {
      PROPSHEETPAGE propSheetPage = {0};
      propSheetPage.lParam = lParam;
      return dispositionSettingsHandler(hwnd,msg,wParam,(long)&propSheetPage);
   }
   return dispositionSettingsHandler(hwnd,msg,wParam,lParam);
   }


   LRESULT CALLBACK InsertPDF::_IOleObject::dispositionSettingsHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {

   resultDisposition *p = (resultDisposition *)GetWindowLong(hwnd,GWL_USERDATA);

#include "dispositionSettingsBody.cpp"

   return (LRESULT)FALSE;
   }
