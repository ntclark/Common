
#include <windows.h>

#include <olectl.h>

#include "InsertPDF.h"

   WNDPROC InsertPDF::_IOleObject::nativePropertySheetFrameHandler = NULL;
   long InsertPDF::_IOleObject::nativePropertySheetFrameHandlerRefCount = 0L;
   HWND InsertPDF::_IOleObject::hwndPropertySheetFrame = NULL;

   InsertPDF::_IOleObject::_IOleObject(InsertPDF *pp) :

      pParent(pp),

      pIOleControl(NULL),
      pIDataObject(NULL),
      pIOleInPlaceObject(NULL),
      pIOleInPlaceActiveObject(NULL),
      pIViewObjectEx(NULL),
      pIProvideClassInfo2(NULL),
      pIPersistStreamInit(NULL),
      pIPersistStorage(NULL),
      pIQuickActivate(NULL),
      pISpecifyPropertyPages(NULL),
      pIGPropertyPageClient(NULL),
      pICursiVisionFrontEnd(NULL),
      pIRunnableObject(NULL),

      pOleAdviseHolder(NULL),
      pDataAdviseHolder(NULL),

      pViewAdviseSink(NULL),
      dwViewAdviseSinkConnection(0L),
      adviseSink_dwAspect(0L),
      adviseSink_advf(0L),

      pIOleClientSite_MySite(NULL),
      pIOleInPlaceSite_MySite(NULL),
   
      connectionPointContainer(this),
      connectionPoint_PropertyNotifySink(this,IID_IPropertyNotifySink),
      connectionPoint_CursiVisionEvents(this,IID_ICursiVisionEvents),
      enumConnectionPoints(0),
      enumConnections(0),

      showToolBar(true),
      showStatusBar(true),
      showAdobeToolBar(true),
      showSignatureControlPanel(true),

      hwndDispositionSettings(NULL),
      hwndAdditionalBackEnds(NULL),
      hwndControlProperties(NULL),
      hwndTemplateProperties(NULL),
      hwndRecognitionProperties(NULL),
      hwndSigningLocationsProperties(NULL),
      hwndDataFields(NULL),

      pTemplateDocument(NULL),

      isRunning(false),

      refCount(0)

   {

   pIOleControl = new _IOleControl(this);
   pIDataObject = new _IDataObject(this);
   pIOleInPlaceObject = new _IOleInPlaceObject(this);
   pIOleInPlaceActiveObject = new _IOleInPlaceActiveObject(this);
   pIProvideClassInfo2 = new _IProvideClassInfo2(this);
   pIViewObjectEx = new _IViewObjectEx(this);
   pIRunnableObject = new _IRunnableObject(this);
   pIPersistStreamInit = new _IPersistStreamInit(this);
   pIPersistStorage = new _IPersistStorage(this);
   pIQuickActivate = new _IQuickActivate(this);
   pISpecifyPropertyPages = new _ISpecifyPropertyPages(this);
   pICursiVisionFrontEnd = new _ICursiVisionFrontEnd(this);
   pIGPropertyPageClient = new _IGPropertyPageClient(this);

   containerSize.cx = 350;
   containerSize.cy = 350;

   pIPropertyPage[0] = new _IPropertyPage(this,CLSID_CursiVisionPropertyPage);
   pIPropertyPage[1] = new _IPropertyPage(this,CLSID_CursiVisionBackEndPropertyPage);
   pIPropertyPage[2] = new _IPropertyPage(this,CLSID_CursiVisionControlPropertyPage);
   pIPropertyPage[3] = new _IPropertyPage(this,CLSID_CursiVisionTemplatePropertyPage);
   pIPropertyPage[4] = new _IPropertyPage(this,CLSID_CursiVisionRecognitionPropertyPage);
   pIPropertyPage[5] = new _IPropertyPage(this,CLSID_CursiVisionSigningLocationsPropertyPage);
   pIPropertyPage[6] = new _IPropertyPage(this,CLSID_CursiVisionFieldsPropertyPage);

   pOleObjectProperties = (BYTE *)&containerSize;
   oleObjectPropertiesSize = offsetof(_IOleObject,expectedPage) - offsetof(_IOleObject,containerSize) + sizeof(expectedPage);

   memset(pOleObjectProperties,0,oleObjectPropertiesSize);
   memset(ppIUnknownBackEnds,0,sizeof(ppIUnknownBackEnds));
   memset(szRepository,0,sizeof(szRepository));
   memset(szProfile,0,sizeof(szProfile));

   pTemplateDocument = new templateDocument(pInsertPDF -> pICursiVisionServices,NULL,szTemplateDocumentName,expectedRects,expectedText);

   HKEY hKey = NULL;

   RegOpenKeyEx(HKEY_LOCAL_MACHINE,"Software\\InnoVisioNate",0L,KEY_QUERY_VALUE,&hKey);

   if ( hKey ) {
      DWORD cb = MAX_PATH;
      DWORD dwType = REG_SZ;
      RegQueryValueEx(hKey,"Profile Repository",0L,&dwType,(BYTE *)szRepository,&cb);
      RegCloseKey(hKey);
   }

   return;
   }


   InsertPDF::_IOleObject::~_IOleObject() {

   for ( long k = 0; 1; k++ ) {
      if ( ! ppIUnknownBackEnds[k] )
         break;
      ppIUnknownBackEnds[k] -> Release();
   }

   delete pIOleControl;
   delete pIDataObject;
   delete pIOleInPlaceObject;
   delete pIOleInPlaceActiveObject;
   delete pIProvideClassInfo2;
   delete pIViewObjectEx;
   delete pIRunnableObject;
   delete pIPersistStreamInit;
   delete pIPersistStorage;
   delete pIQuickActivate;
   delete pISpecifyPropertyPages;
   delete pICursiVisionFrontEnd;

   delete pIPropertyPage[0];
   delete pIPropertyPage[1];
   delete pIPropertyPage[2];
   delete pIPropertyPage[3];
   delete pIPropertyPage[4];
   delete pIPropertyPage[5];
   delete pIPropertyPage[6];

   if ( pTemplateDocument )
      delete pTemplateDocument;

   pTemplateDocument = NULL;

   delete pInsertPDF;

   pInsertPDF = NULL;

#ifdef CURSIVISION_CONTROL_BUILD
   Sleep(1000);
   CoFreeUnusedLibraries();
#endif

   return;
   }


