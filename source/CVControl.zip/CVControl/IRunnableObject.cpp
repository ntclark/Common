/*

                       Copyright (c) 2011 Nathan T. Clark

*/

#include "InsertPDf.h"

   long __stdcall InsertPDF::_IOleObject::_IRunnableObject::QueryInterface(REFIID riid,void **ppv) {

   if ( IID_IRunnableObject == riid )
      *ppv = static_cast<IRunnableObject *>(this); 
   else
      return pParent -> QueryInterface(riid,ppv);
   
   AddRef();
   return S_OK;
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IRunnableObject::AddRef() {
   return pParent -> AddRef();
   }
   unsigned long __stdcall InsertPDF::_IOleObject::_IRunnableObject::Release() {
   return pParent -> Release();
   }


   STDMETHODIMP InsertPDF::_IOleObject::_IRunnableObject::GetRunningClass(CLSID *pcid) {
   *pcid = CLSID_CursiVision;
   return E_UNEXPECTED;
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IRunnableObject::Run(LPBC pBindingContext) { 
   return S_OK; 
   }

   int __stdcall InsertPDF::_IOleObject::_IRunnableObject::IsRunning() { 
   return 1; 
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IRunnableObject::LockRunning(BOOL,BOOL) { 
   return S_OK; 
   }

   STDMETHODIMP InsertPDF::_IOleObject::_IRunnableObject::SetContainedObject(BOOL) { 
   return S_OK; 
   }

