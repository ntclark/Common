/*
                       Copyright (c) 2009,2010,2011,2012 Nathan T. Clark
*/

#include "insertPDF.h"

#include "dispositionSettingsDefines.h"

#ifdef CURSIVISION_CONTROL_BUILD
#undef REGISTER_TOOLTIPS
#define LOAD_ADDITIONAL                                                                                        \
{                                                                                                              \
   PUT_BOOL(((_IOleObject *)(p -> pParent)) -> showToolBar,IDDI_DISPOSITION_SHOW_CURSIVISION_TOOLBAR)          \
   PUT_BOOL(((_IOleObject *)(p -> pParent)) -> showStatusBar,IDDI_DISPOSITION_SHOW_CURSIVISION_STATUSBAR)      \
   PUT_BOOL(((_IOleObject *)(p -> pParent)) -> showSignatureControlPanel,IDDI_DISPOSITION_SHOW_CONTROL_PANEL)  \
   PUT_BOOL(((_IOleObject *)(p -> pParent)) -> showAdobeToolBar,IDDI_DISPOSITION_SHOW_ADOBE_TOOLBAR)           \
}
#define UNLOAD_ADDITIONAL                                                                                      \
{                                                                                                              \
   GET_BOOL(((_IOleObject *)(p -> pParent)) -> showToolBar,IDDI_DISPOSITION_SHOW_CURSIVISION_TOOLBAR)          \
   GET_BOOL(((_IOleObject *)(p -> pParent)) -> showStatusBar,IDDI_DISPOSITION_SHOW_CURSIVISION_STATUSBAR)      \
   GET_BOOL(((_IOleObject *)(p -> pParent)) -> showSignatureControlPanel,IDDI_DISPOSITION_SHOW_CONTROL_PANEL)  \
   GET_BOOL(((_IOleObject *)(p -> pParent)) -> showAdobeToolBar,IDDI_DISPOSITION_SHOW_ADOBE_TOOLBAR)           \
}
#define REGISTER_TOOLTIPS(hInst)                                        \
{                                                                       \
   REGISTER_TOOLTIP(hInst,IDDI_DISPOSITION_SHOW_CURSIVISION_TOOLBAR)    \
   REGISTER_TOOLTIP(hInst,IDDI_DISPOSITION_SHOW_CURSIVISION_STATUSBAR)  \
   REGISTER_TOOLTIP(hInst,IDDI_DISPOSITION_SHOW_ADOBE_TOOLBAR)          \
   REGISTER_TOOLTIP(hInst,IDDI_DISPOSITION_SHOW_CONTROL_PANEL)          \
}
#else
#define LOAD_ADDITIONAL
#define UNLOAD_ADDITIONAL
#endif

   static HWND hwndToolTips = NULL;
   static char szCurrentToolTipText[1024];

   LRESULT CALLBACK InsertPDF::_IOleObject::controlPropertiesHandlerISpecifyPropertyPageImplementation(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {
   if ( WM_INITDIALOG == msg ) {
      PROPSHEETPAGE propSheetPage = {0};
      propSheetPage.lParam = lParam;
      return controlPropertiesHandler(hwnd,msg,wParam,(long)&propSheetPage);
   }
   return controlPropertiesHandler(hwnd,msg,wParam,lParam);
   }

   LRESULT CALLBACK InsertPDF::_IOleObject::controlPropertiesHandler(HWND hwnd,UINT msg,WPARAM wParam,LPARAM lParam) {

   resultDisposition *p = (resultDisposition *)GetWindowLong(hwnd,GWL_USERDATA);

   switch ( msg ) {

   case WM_INITDIALOG: {

      PROPSHEETPAGE *pPage = reinterpret_cast<PROPSHEETPAGE *>(lParam);

      p = (resultDisposition *)pPage -> lParam;

      SetWindowLong(hwnd,GWL_USERDATA,(long)p);

      LOAD_ADDITIONAL

      hwndToolTips = CreateWindowEx(NULL, TOOLTIPS_CLASS, NULL,WS_POPUP | TTS_NOPREFIX | TTS_ALWAYSTIP | TTS_BALLOON,CW_USEDEFAULT, CW_USEDEFAULT,
                                          CW_USEDEFAULT,CW_USEDEFAULT,hwnd,NULL,hModule,NULL);

#ifndef _DEBUG
      SetWindowPos(hwndToolTips, HWND_TOPMOST,0, 0, 100, 100,SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
#endif

      SendMessage(hwndToolTips,TTM_ACTIVATE,(WPARAM)TRUE,0L);

      SendMessage(hwndToolTips,TTM_SETDELAYTIME,(WPARAM)TTDT_AUTOPOP,MAKELONG(5000,0));

      REGISTER_TOOLTIPS(hModule)

      }
      return LRESULT(FALSE);

   case WM_DESTROY: {
      }
      break;

   case WM_NOTIFY: {

      NMHDR *pNotifyHeader = (NMHDR *)lParam;

      switch ( pNotifyHeader -> code ) {

      case PSN_APPLY: {

         PSHNOTIFY *pNotify = (PSHNOTIFY *)lParam;

         if ( pNotify -> lParam ) {

            for ( long k = IDDI_DISPOSITION_AS_CONTROL_FIRST; k <= IDDI_DISPOSITION_AS_CONTROL_LAST; k++ )
               SetParent(GetDlgItem(GetDlgItem(hwnd,IDDI_DISPOSITION_AS_CONTROL_BACKGROUND),k),hwnd);

            UNLOAD_ADDITIONAL

         }

         SetWindowLong(hwnd,DWL_MSGRESULT,PSNRET_NOERROR);

         InvalidateRect(hwndMainFrame,NULL,TRUE);

         }
         return (LRESULT)TRUE;

#ifdef REGISTER_TOOLTIPS
      case TTN_GETDISPINFO: {
         NMTTDISPINFO *pToolTipDispInfo;
         pToolTipDispInfo = (LPNMTTDISPINFO)pNotifyHeader;
         pToolTipDispInfo -> lpszText = szCurrentToolTipText;
         HFONT hFont = (HFONT)SendMessage(hwndToolTips,WM_GETFONT,0L,0L);
         LOGFONT fontInfo;
         GetObject(hFont,sizeof(LOGFONT),&fontInfo);

         LoadString(hModule,pToolTipDispInfo -> lParam,szCurrentToolTipText,1024);

         if ( fontInfo.lfHeight )
            SendMessage(pNotifyHeader -> hwndFrom,TTM_SETMAXTIPWIDTH,0,strlen(szCurrentToolTipText) * abs(fontInfo.lfHeight) / 4);
         else
            SendMessage(pNotifyHeader -> hwndFrom,TTM_SETMAXTIPWIDTH,0,256);
         }
         return 0;
#endif

      }

      }
      break;

   default:
      break;
   }

   return LRESULT(FALSE);
   }